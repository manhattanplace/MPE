<?php
include 'func/admin.class.php';
$authorizer = new Authorizer;
$authorizer->logout();
?>